# CarrierWave.configure do |config|
#     config.fog_provider = 'fog/aws'                             # required
#     config.fog_credentials = {
#       provider:              'AWS',                             # required
#       aws_access_key_id:     ENV['AWS_ACCESS_KEY_ID'],          # required
#       aws_secret_access_key: ENV['AWS_SECRET_ACCESS_KEY'],      # required
#       region:                ENV['AWS_REGION'],
#       endpoint:              ENV['AWS_ENDPOINT']                # optional, defaults to 'us-east-1'

#     }
#     config.fog_directory  = ENV['AWS_BUCKET']
#     # config.s3_access_policy = :public_read
#     config.fog_public     = true                             # optional, defaults to true

#   end

  